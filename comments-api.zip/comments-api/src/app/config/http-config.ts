export const httpConfig = {
  url: 'http://85.160.64.233:3000'
};
