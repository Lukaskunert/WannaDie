export interface Token {
  access_token: string;
}
